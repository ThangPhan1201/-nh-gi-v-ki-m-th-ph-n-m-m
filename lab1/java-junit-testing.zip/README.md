# Java JUnit Testing Project

## Features
- Prime number checking
- Statement coverage test
- Path coverage test

## Run
Use Gradle to run tests:
./gradlew test
