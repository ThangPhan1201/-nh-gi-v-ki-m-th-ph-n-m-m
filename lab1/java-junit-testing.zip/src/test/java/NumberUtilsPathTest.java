import static org.junit.Assert.*;
import org.junit.Test;

public class NumberUtilsPathTest {

    @Test
    public void testLessThan2() {
        assertFalse(NumberUtils.isPrime(0));
        assertFalse(NumberUtils.isPrime(1));
    }

    @Test
    public void testPrime() {
        assertTrue(NumberUtils.isPrime(2));
        assertTrue(NumberUtils.isPrime(3));
    }

    @Test
    public void testComposite() {
        assertFalse(NumberUtils.isPrime(4));
        assertFalse(NumberUtils.isPrime(9));
    }

    @Test
    public void testPrimeLarge() {
        assertTrue(NumberUtils.isPrime(11));
    }
}
