import static org.junit.Assert.*;
import org.junit.Test;

public class NumberUtilsTest {

    @Test
    public void testIsPrime() {
        assertFalse(NumberUtils.isPrime(1));
        assertTrue(NumberUtils.isPrime(2));
        assertFalse(NumberUtils.isPrime(4));
    }
}
